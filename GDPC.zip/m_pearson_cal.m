function P=m_pearson_cal(Data1,Data2,group1,group2)
n=size(Data1,1);
ug1=unique(group1);
ug2=unique(group2);
ng1=length(ug1);
ng2=length(ug2);
maf=sum(Data2)/2/n;
mData1=zeros(n,ng1);

for i=1:ng1
    if iscell(group1)
        ingroup1=Data1(:,strcmp(group1,ug1{i}));
    else
        ingroup1=Data1(:,group1==ug1(i));
    end
    mData1(:,i)=mean(ingroup1,2);


end
mData2=zeros(n,ng2);
for i=1:ng2
    if iscell(group2)
        ingroup2=Data2(:,strcmp(group2,ug2{i}));
        inmaf=maf(:,strcmp(group2,ug2{i}));
    else
        ingroup2=Data2(:,group2==ug2(i));
        inmaf=maf(:,group2==ug2(i));
    end
    mData2(:,i)=mean(ingroup2./repmat(sqrt(inmaf.*(1-inmaf)),n,1),2);
%     mData2(:,i)=mean(ingroup2,2);
end
mData1=zscore(mData1);
mData2=zscore(mData2);

corr=mData1'*mData2/(n-1);
T=sqrt(n-2)*corr./sqrt(1-corr.^2);
P=min(1-cdf('t',T,n-2),cdf('t',T,n-2))*2;
end



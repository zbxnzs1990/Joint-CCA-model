function P=dis_fast_partial_cal(res1,res2,group1,group2)
[n,p2]=size(res2);
Full_dis1=pdist(res1)'.^2;
Full_dis2=pdist(res2)'.^2;
P_dis1=cal_dmatrix(res1,Full_dis1,group1);
P_dis2=cal_dmatrix(res2,Full_dis2,group2);
pR=P_dis1'*P_dis2;
T=sqrt((n*(n-3))/2-1)*pR./sqrt(1-pR.^2);
P=1-cdf('t',T,n*(n-3)/2);
end


function U=Ucenter(dis,n)
for i=1:size(dis,2)
    D=squareform(dis(:,i).^0.5);
    D_row=sum(D);
    D_t=sum(D_row);
    D_centered=D-repmat(D_row,n,1)/(n-2)-repmat(D_row',1,n)/(n-2)+D_t/(n-1)/(n-2);
    D_centered=D_centered-diag(diag(D_centered));
    U(:,i)=D_centered(:);
end
end



function P_dis=cal_dmatrix(res,dis,group)
[n,~]=size(res);
group_id=unique(group);
n_group=length(group_id);
for i=1:n_group
    if iscell(group)
        res_group=res(:,strcmp(group,group_id{i}));
    else
        res_group=res(:,group==group_id(i));
    end
    D=pdist(res_group)'.^2;
    U_dis=Ucenter(D,n);
    U_c=Ucenter(dis-D,n);
    P_dis(:,i)=U_dis-U_dis'*U_c/sum(U_c.^2)*U_c;
    P_dis(:,i)=P_dis(:,i)/norm(P_dis(:,i));
end

end

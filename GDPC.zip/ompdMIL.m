function [res,bk] = ompdMIL(x, dict,dictT,d)
% initialization
type='hdbic';
atomlen = size(dict,1);
% dictsize = size(dict,2);
natom=fix((1+log(d))*sqrt(atomlen/log(d)));
% natom=10;
%
dictTx=dictT*x;
projections = dictTx;
dualbasis = zeros(atomlen,natom);
stemp = zeros(natom,1);
gamma = zeros(natom,1);
k = 0;
opt_ic=1e10;
res=x;
while k < natom
    k=k+1;
    % find index of maximum magnitude projection
    [~,maxindex] = max(projections.^2); %cost N
    newgam = maxindex(1);
    gamma(k) = newgam;
    
    % update QR factorization, projections, and residual energy
    if k==1
        % update dualbasis
        dualbasis(:,1) = dict(:,newgam);
        % find solution
        stemp(1) = projections(newgam);
        % update projections
        %         normr2 = normx2 - stemp(1)*stemp(1);
        residue=x-dict(:,newgam)*stemp(1);
        projections = dictT*residue; % cost Nk
    else
        % update dualbasis
        gammakm1 = gamma(1:k-1);
        tempbasis = dualbasis(:,1:k-1);
        vh = tempbasis'*dict(:,newgam); % cost Mk
        projphi = dict(:,gammakm1)*vh;  % cost Mk
        vv = dict(:,newgam) - projphi; % cost M
        lambda = 1/(1-projphi'*projphi);  % cost M
        lambdavh = lambda*vh; % cost k
        lambdavv = lambda*vv; % cost M
        lambdavvvhH = vv*lambdavh'; % cost Mk
        dualbasis(:,1:k-1) = tempbasis - lambdavvvhH; % cost Mk
        dualbasis(:,k) = lambdavv;
        % find solution
        delta = lambda*dictTx(newgam) - dictTx(gammakm1)'*lambdavh; % cost k
        stemp(1:k) = stemp(1:k) - delta*[vh; -1]; % cost k
        %         normr2 = normr2 + delta*delta*sum(vv.^2) - 2*delta*projections(newgam); % cost k
        residue=x-dict(:,gamma(1:k))*stemp(1:k);
        projections = dictT*residue; % cost Nk
    end
    if strcmp(type,'hdaic')==1
        ic=atomlen*log(mse(residue))+2*k*log(d);
    elseif strcmp(type,'hdbic')==1
        ic=atomlen*log(mse(residue))+k*2*log(max(d,atomlen));
    elseif strcmp(type,'aic')==1
        ic=atomlen*log(mse(residue))+2*k;
    end
    if (ic<=opt_ic)
        res=residue;bk=k;opt_ic=ic;
    end
end

end

function y=mse(x)
y=mean(x.^2);
end

function p_cross=BiFDR(p,sig)
psort=sort(p(:));
psort_fdr=psort./(1:length(psort))'*length(psort);
fdr_posi=find(psort_fdr<sig,1,'last');
p_cut=psort(fdr_posi);
p_cross=p<=p_cut;
end
function P=m_partial_cal(Data1,Data2,group1,group2)
n=size(Data1,1);
ug1=unique(group1);
ug2=unique(group2);
ng1=length(ug1);
ng2=length(ug2);
maf=sum(Data2)/2/n;
mData1=zeros(n,ng1);
mData2=zeros(n,ng2);
for i=1:ng1
    if iscell(group1)
        ingroup1=Data1(:,strcmp(group1,ug1{i}));
    else
        ingroup1=Data1(:,group1==ug1(i));
    end
    mData1(:,i)=mean(ingroup1,2);

    if iscell(group2)
        ingroup2=Data2(:,strcmp(group2,ug2{i}));
        inmaf=maf(:,strcmp(group2,ug2{i}));
    else
        ingroup2=Data2(:,group2==ug2(i));
        inmaf=maf(:,group2==ug2(i));
    end
    mData2(:,i)=mean(ingroup2./repmat(sqrt(inmaf.*(1-inmaf)),n,1),2);
end

mData1=zscore(mData1)/sqrt(n-1);
mData2=zscore(mData2)/sqrt(n-1);

[res_1,bk1]=OMP_HDBIC(mData1,ug1);
[res_2,bk2]=OMP_HDBIC(mData2,ug2);



nres1=sqrt(sum(res_1.^2));
nres2=sqrt(sum(res_2.^2));
corr=res_1'*res_2./(nres1'*nres2);

T=sqrt(n-2)*corr./sqrt(1-corr.^2);
P=min(1-cdf('t',T,n-2),cdf('t',T,n-2))*2;

end



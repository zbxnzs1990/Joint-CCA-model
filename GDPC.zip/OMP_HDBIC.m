function [res,bk]=OMP_HDBIC(Data,groupID)
[n,p]=size(Data);
res=zeros(n,p);
% num_screen=fix(n*log10(p));
bk=zeros(p,1);
for i=1:p
    %% Screening
    if iscell(groupID)
        out_group=~strcmp(groupID,groupID{i});
    else
    out_group=(groupID~=groupID(i));
    end
%     w=Data(:,i)'*Data;
%     sort_w=sort(abs(w(out_group)),'descend');
%     thresh_w=sort_w(num_screen);
%     basis_screen=Data(:,out_group'&(abs(w)>thresh_w));
    basis_screen=Data(:,out_group');
    [res(:,i),bk(i)]=ompdMIL(Data(:,i),basis_screen,basis_screen',p);
end
end


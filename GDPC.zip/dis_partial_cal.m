function P=dis_partial_cal(res1,res2,group1,group2)
n=size(res1,1);
ng1=length(unique(group1));
ng2=length(unique(group2));
Full_dis=pdist([res1,res2])'.^2;
M_dis1=cal_dmatrix(res1,group1);
U_dis1=Ucenter(M_dis1,n);
M_dis2=cal_dmatrix(res2,group2);
U_dis2=Ucenter(M_dis2,n);
T=zeros(ng1,ng2);
for i=1:ng1
    for j=1:ng2
        disc=Full_dis-M_dis1(:,i)-M_dis2(:,j);
        U_disc=Ucenter(disc,n);
        R12=U_dis1(:,i)'*U_dis2(:,j)/norm(U_dis1(:,i))/norm(U_dis2(:,j));
        R1c=U_dis1(:,i)'*U_disc/norm(U_dis1(:,i))/norm(U_disc);
        R2c=U_dis2(:,j)'*U_disc/norm(U_dis2(:,j))/norm(U_disc);
        pR=(R12-R1c*R2c)/sqrt(1-R1c^2)/sqrt(1-R2c^2);
%         pR=R12;
        T(i,j)=sqrt((n*(n-3))/2-1)*pR./sqrt(1-pR.^2);
    end
end
P=1-cdf('t',T,n*(n-3)/2);
end


function U=Ucenter(dis,n)
for i=1:size(dis,2)
    D=squareform(dis(:,i).^0.5);
    D_row=sum(D);
    D_t=sum(D_row);
    D_centered=D-repmat(D_row,n,1)/(n-2)-repmat(D_row',1,n)/(n-2)+D_t/(n-1)/(n-2);
    D_centered=D_centered-diag(diag(D_centered));
    U(:,i)=D_centered(:);
end
end


% function [M,S]=cal_dmatrix_hd(res,group)
% [n,~]=size(res);
% group_id=unique(group);
% n_group=length(group_id);
% M=zeros(n^2,n_group);
% S=zeros(n,n_group);
% for i=1:n_group
%     if iscell(group)
%         res_group=res(:,strcmp(group,group_id{i}));
%     else
%         res_group=res(:,group==group_id(i));
%     end
%    D=pdist(res_group);
%    D=squareform(D);
%    D_row=mean(D);
%    D_t=mean(D_row);
%    D_centered=D-repmat(D_row,n,1)-repmat(D_row',1,n)+D_t;
%    D_hd=(D_centered-D/n)*n/(n-1);
%    D_hd=D_hd-diag(diag(D_hd))+diag((D_row-D_t)*n/(n-1));
%    S(:,i)=diag(D_hd);
%    M(:,i)=D_hd(:);
% %    S(:,i)=diag(D_hd);
% end
%
% end


function D=cal_dmatrix(res,group)
[n,~]=size(res);
group_id=unique(group);
n_group=length(group_id);
for i=1:n_group
    if iscell(group)
        res_group=res(:,strcmp(group,group_id{i}));
    else
        res_group=res(:,group==group_id(i));
    end
    D(:,i)=pdist(res_group).^2;
end

end

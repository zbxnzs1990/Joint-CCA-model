function pnet=post_partial_cal(Data1,Data2,group1,group2,screen_pairs)
[n,p1]=size(Data1);
[~,p2]=size(Data2);
% group_id1=unique(group1);
% group_id2=unique(group2);
p=p1+p2;
num_screen=fix(n*log10(p));
n_pair=size(screen_pairs,1);
pnet=zeros(n_pair,1);
for i=1:n_pair
   in_pair1=(group1==screen_pairs(i,1));
   in_pair2=(group2==screen_pairs(i,2));
   Data_in1=Data1(:,in_pair1);
   Data_in2=Data1(:,in_pair2);
   Data_out=[Data1(:,~in_pair1),Data2(:,~in_pair2)];
   res1=zeros(size(Data_in1));
   for j= 1:size(Data_in1,2)
    w=Data_in1(:,j)'*Data_out;
    sort_w=sort(abs(w),'descend');
    thresh_w=sort_w(num_screen);
    basis_screen=Data_out(:,abs(w)>thresh_w);
    res1(:,j)=ompdMIL(Data_in1(:,j),basis_screen,basis_screen',p);
   end
   res2=zeros(size(Data_in2));
    for j= 1:size(Data_in2,2)
    w=Data_in2(:,j)'*Data_out;
    sort_w=sort(abs(w),'descend');
    thresh_w=sort_w(num_screen);
    basis_screen=Data_out(:,abs(w)>thresh_w);
    res2(:,j)=ompdMIL(Data_in2(:,j),basis_screen,basis_screen',p);
   end
   pnet(i)=cal_pdc(res1,res2);
end
end

function p=cal_pdc(res1,res2)
n=size(res1,1);
[D_matrix1,S1]=cal_dc(res1);
[D_matrix2,S2]=cal_dc(res2);
pnet=D_matrix1'*D_matrix2*n;
pnet=pnet./(S1'*S2);
p=sqrt(abs(pnet));
end


function [M,S]=cal_dc(res)
[n,~]=size(res);
   res_group=res;
   D=pdist(res_group);
   D=squareform(D);
   D_row=mean(D);
   D_t=mean(D_row);
   D_centered=D-repmat(D_row,n,1)-repmat(D_row',1,n)+D_t;
   D_centered=D_centered-diag(diag(D_centered));
   M=D_centered(:)/n;
   S=D_t;
end
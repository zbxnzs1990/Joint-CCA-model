function [res,bk]=Lasso_HDBIC(Data,groupID)
[n,p]=size(Data);
res=zeros(n,p);
% num_screen=fix(n*log10(p));
bk=zeros(p,1);
for i=1:p
    %% Screening
    if iscell(groupID)
        out_group=~strcmp(groupID,groupID{i});
    else
    out_group=(groupID~=groupID(i));
    end
    basis_screen=Data(:,out_group');
    [res(:,i),bk(i)]=LassoMIL(Data(:,i),basis_screen);
end
end

function [res,bk]=LassoMIL(y,A)
n=length(y);
[n,p]=size(A);
lambda=sqrt(2*log(p/sqrt(n))/n);
x=lasso(A,y,'Lambda',lambda);
res=y-A*x;
bk=sum(abs(x)>0);
end
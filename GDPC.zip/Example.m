clear;clc;close all;
load FMRI_simu_para.mat;
load upenn_simu.mat;% The SNP data are available upon request.
c=clock;
rng(c(6));
%% Generete data
for nn=1:10
    n=100*nn;
    n_edge=100;
    sigma=0.5;
    ratio=0.01;
    p1=size(W,1);
    [n_rand,p2]=size(SNP_data);
    for n_rep=1:10
        Data1=mvnrnd(zeros(p1,1),W,n);
        rsub=randperm(n_rand);
        Data2=SNP_data(rsub(1:n),:);
        ROI=unique(ROIID_new);
        Gene=unique(GeneID);
        n_r=length(ROI);
        n_g=length(Gene);
        edge_r=randi(n_r,[n_edge,1]);
        edge_g=randi(n_g,[n_edge,1]);
        
        for i=1:n_edge
            voxel_in=ROIID_new==ROI(edge_r(i));
            snp_in=strcmp(Gene{edge_g(i)},GeneID);
            n_voxel=sum(voxel_in);
            n_snp=sum(snp_in);
            t_edge=rand(n_snp,n_voxel)>ratio;
            while sum(~t_edge(:))==0
                t_edge=rand(n_snp,n_voxel)>ratio;
            end
            t_mtx=sigma*randn(n_snp,n_voxel);
            t_mtx(t_edge)=0;
            Data1(:,voxel_in)=Data1(:,voxel_in)+Data2(:,snp_in)*t_mtx;
        end
        % Pearsons
        P4=m_pearson_cal(Data1,Data2,ROIID_new,GeneID);


        Data1=zscore(Data1)/sqrt(size(Data1,1)-1);
        Data2=zscore(Data2)/sqrt(size(Data2,1)-1);
        % GPDC
        [res_1,bk_1]=OMP_HDBIC(Data1,ROIID_new);
        [res_2,bk_2]=OMP_HDBIC(Data2,GeneID);
        P1=ini_partial_cal_hd(res_1,res_2,ROIID_new,GeneID);
        %dis
        P2=ini_partial_cal_hd(Data1,Data2,ROIID_new,GeneID);
        %pdis
        P3=dis_fast_partial_cal(Data1,Data2,ROIID_new,GeneID);
        %% Analysis
        for np=1:50
            % p_cross=BiFDR(T1,n,0.01);
            p_cut=2^(1-np);
            p_cross=BiP(P1,p_cut);
            gt_edge=sub2ind([n_r,n_g],edge_r,edge_g);
            n_p1(n_rep,np,nn)=length(find(p_cross));
            n_t1(n_rep,np,nn)=length(intersect(gt_edge,find(p_cross)));
            % p_cross=BiFDR(T2,n,0.01);
            p_cross=BiP(P2,p_cut);
            gt_edge=sub2ind([n_r,n_g],edge_r,edge_g);
            n_p2(n_rep,np,nn)=length(find(p_cross));
            n_t2(n_rep,np,nn)=length(intersect(gt_edge,find(p_cross)));
            % p_cross=BiFDR(T3,n,0.01);
            p_cross=BiP(P3,p_cut);
            gt_edge=sub2ind([n_r,n_g],edge_r,edge_g);
            n_p3(n_rep,np,nn)=length(find(p_cross));
            n_t3(n_rep,np,nn)=length(intersect(gt_edge,find(p_cross)));
            p_cross=BiP(P4,p_cut);
            gt_edge=sub2ind([n_r,n_g],edge_r,edge_g);
            n_p4(n_rep,np,nn)=length(find(p_cross));
            n_t4(n_rep,np,nn)=length(intersect(gt_edge,find(p_cross)));
        end
    end
end

function P=ini_partial_cal_hd(res1,res2,group1,group2)
n=size(res1,1);
[D_matrix1,S1]=cal_dmatrix_hd(res1,group1);
[D_matrix2,S2]=cal_dmatrix_hd(res2,group2);

pnet_between=D_matrix1'*D_matrix2-S1'*S2/(n-2)*n;
pnet_within1=D_matrix1'*D_matrix1-S1'*S1/(n-2)*n;
pnet_within2=D_matrix2'*D_matrix2-S2'*S2/(n-2)*n;
% size(pnet_between)
% size(pnet_within1)
% size(pnet_within2)
pnet=pnet_between./sqrt(diag(pnet_within1)*diag(pnet_within2)');
T=sqrt((n*(n-3))/2-1)*pnet./sqrt(1-pnet.^2);
P=1-cdf('t',T,n*(n-3)/2);
% pnet=sqrt(abs(pnet));

end



function [M,S]=cal_dmatrix_hd(res,group)
[n,~]=size(res);
group_id=unique(group);
n_group=length(group_id);
M=zeros(n^2,n_group);
S=zeros(n,n_group);
for i=1:n_group
    if iscell(group)
        res_group=res(:,strcmp(group,group_id{i}));
    else
        res_group=res(:,group==group_id(i));
    end
   D=pdist(res_group);
   D=squareform(D);
   D_row=mean(D);
   D_t=mean(D_row);
   D_centered=D-repmat(D_row,n,1)-repmat(D_row',1,n)+D_t;
   D_hd=(D_centered-D/n)*n/(n-1);
   D_hd=D_hd-diag(diag(D_hd))+diag((D_row-D_t)*n/(n-1));
   S(:,i)=diag(D_hd);
   M(:,i)=D_hd(:);
%    S(:,i)=diag(D_hd);
end

end

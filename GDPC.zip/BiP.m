function p_cross=BiP(p,sig)

p_cross=p<sig;
end